
# PubMed Fetcher

## Overview
This tool fetches research papers from PubMed based on a user-supplied query and filters results for authors affiliated with biotech/pharma companies.

## Setup
```bash
poetry install
```

## Run
```bash
poetry run get-papers-list "covid vaccine" -f results.csv
```

## Features
- Supports full PubMed query syntax
- Filters for non-academic/industry authors
- Exports to CSV
